function NgayGio(){
    var ngay=new Date();
    document.getElementById("ngay").innerHTML=ngay;
}